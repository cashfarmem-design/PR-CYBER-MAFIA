# PR CYBER MAFIA

Plataforma de cursos de Cybersecurity / Ethical Hacking para ambientes autorizados.

## Estrutura
- `curso-01-ethical-hacking/` — curso em produção
- `cursos/` — estrutura dos demais cursos
- `sistema-de-acesso/` — arquitetura do cadastro e acesso permanente
- `config/` — modelos de configuração
- `docs/` — documentação do projeto

## Acesso
O aluno deverá informar:
1. ID/nome de usuário do Discord
2. Curso desejado
3. Chave de acesso

Após validação, o sistema registra o acesso como permanente e libera o cargo/canal correspondente.

> Chaves reais e credenciais nunca devem ser commitadas no GitHub. Use variáveis de ambiente ou banco de dados seguro.

## Uso educacional
Todo conteúdo ofensivo deve ser executado somente em laboratórios, CTFs e sistemas para os quais exista autorização explícita.
