# Arquitetura

## Fluxo do aluno
1. `/entrar` ou botão de acesso.
2. Informar usuário/identificador.
3. Selecionar curso.
4. Informar chave.
5. Validar chave no banco.
6. Registrar ativação.
7. Liberar cargo e canais do curso.
8. Manter `expires_at = NULL` para acesso permanente.

## Dados recomendados
### users
- discord_user_id
- username
- created_at

### course_keys
- key_hash
- course_id
- active
- max_uses
- created_at

### enrollments
- user_id
- course_id
- activated_at
- expires_at
- status

### progress
- user_id
- course_id
- lesson_id
- completed_at

## Segurança
- Armazenar somente hash das chaves quando possível.
- Nunca registrar token do Discord em logs.
- Não colocar chaves reais em código-fonte.
- Validar permissões no servidor.
- Registrar ações administrativas.
