# Curso 10 — John the Ripper

**Status:** Planejado  
**Acesso:** Permanente após validação  
**Estrutura padrão:** vídeo de 10 minutos + 5 exercícios + 100 questões + lab/CTF + desafio final + conclusão.

Conteúdo prático somente em ambientes autorizados.
