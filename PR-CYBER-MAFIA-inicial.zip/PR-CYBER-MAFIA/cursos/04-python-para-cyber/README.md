# Curso 04 — Python para Cyber

**Status:** Planejado  
**Acesso:** Permanente após validação  
**Estrutura padrão:** vídeo de 10 minutos + 5 exercícios + 100 questões + lab/CTF + desafio final + conclusão.

Conteúdo prático somente em ambientes autorizados.
