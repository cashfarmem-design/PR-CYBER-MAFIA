# Roteiro — Vídeo de 10 minutos

00:00–01:00 — Introdução e autorização  
01:00–03:00 — Fundamentos  
03:00–05:00 — Reconhecimento e enumeração  
05:00–07:30 — Análise e validação controlada  
07:30–09:00 — Demonstração em laboratório autorizado  
09:00–10:00 — Revisão e próximos passos
