# Gabarito

O gabarito administrativo não deve ser publicado em repositório público.

Mantenha a versão oficial em armazenamento privado ou variável/serviço administrativo protegido.
