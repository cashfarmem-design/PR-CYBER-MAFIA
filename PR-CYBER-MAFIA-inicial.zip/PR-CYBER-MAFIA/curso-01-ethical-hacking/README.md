# Curso 01 — Ethical Hacking

**Status:** Em produção  
**Acesso:** Permanente após validação  
**Vídeo:** 10 minutos  
**Exercícios:** 5  
**Questões:** 100  
**Formato:** A/B/C/D  
**Lab:** autorizado / CTF

## Estrutura
1. Fundamentos de Ethical Hacking
2. Reconhecimento
3. Enumeração
4. Vulnerabilidades e validação
5. Relatório e correção

## Fluxo
RECONHECER → ENUMERAR → IDENTIFICAR → VALIDAR → DOCUMENTAR → CORRIGIR → RETESTAR

As atividades práticas devem ocorrer somente em ambientes autorizados.
