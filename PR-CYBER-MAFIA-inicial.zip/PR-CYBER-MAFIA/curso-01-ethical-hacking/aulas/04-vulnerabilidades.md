# Aula 04 — Vulnerabilidades

- Condição, causa e impacto
- Validação controlada
- Contexto e risco
- Controles compensatórios
