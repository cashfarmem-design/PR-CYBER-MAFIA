# Aula 01 — Fundamentos

- Autorização e escopo
- Regras de engajamento
- Evidências
- Mínimo impacto
- Rastreabilidade
