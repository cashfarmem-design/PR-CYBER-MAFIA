# Aula 03 — Enumeração

- Serviços e aplicações
- Identificação de tecnologias
- Validação de resultados
- Redução de falsos positivos
