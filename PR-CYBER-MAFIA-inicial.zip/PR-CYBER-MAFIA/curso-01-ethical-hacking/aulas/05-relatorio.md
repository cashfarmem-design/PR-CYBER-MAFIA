# Aula 05 — Relatório

- Evidências mínimas
- Severidade e prioridade
- Recomendações
- Reteste
- Comunicação técnica e executiva
