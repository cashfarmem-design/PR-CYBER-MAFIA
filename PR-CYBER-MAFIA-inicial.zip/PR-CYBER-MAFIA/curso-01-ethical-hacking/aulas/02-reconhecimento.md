# Aula 02 — Reconhecimento

- Inventário de ativos autorizados
- Superfície de ataque
- Hipóteses e evidências
- Correlação de informações
