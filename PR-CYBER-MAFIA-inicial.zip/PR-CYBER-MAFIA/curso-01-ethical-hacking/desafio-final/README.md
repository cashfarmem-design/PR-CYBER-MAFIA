# Desafio Final

Produzir um mini-relatório contendo:
- ativos e escopo;
- metodologia;
- três achados priorizados;
- evidências;
- impacto;
- recomendações;
- plano de reteste.

Pontuação sugerida:
20% metodologia • 25% análise • 25% evidências • 20% recomendações • 10% clareza.
