# Lab / CTF autorizado

Ambiente fictício para treinamento. O aluno deve:
- identificar ativos do escopo;
- mapear a superfície;
- analisar condições fracas intencionais;
- documentar evidências;
- propor correções e reteste.

Não utilizar o exercício contra sistemas reais ou de terceiros.
