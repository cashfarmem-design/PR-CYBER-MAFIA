# Exercícios

## Exercício 01
Fundamentos, ética e escopo — 20 questões.

## Exercício 02
Reconhecimento e enumeração — 20 questões.

## Exercício 03
Vulnerabilidades e análise — 20 questões.

## Exercício 04
Relatório, evidências e priorização — 20 questões.

## Exercício 05
Cenários avançados e desafio final — 20 questões.

**Total: 100 questões.**
