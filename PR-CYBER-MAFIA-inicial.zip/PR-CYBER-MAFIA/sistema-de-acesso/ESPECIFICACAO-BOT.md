# Especificação do Bot

## Comandos sugeridos
- `/entrar` — inicia o cadastro
- `/meus-cursos` — mostra cursos ativos
- `/progresso` — mostra progresso
- `/ajuda` — orientações
- `/admin-ativar` — uso administrativo
- `/admin-revogar` — uso administrativo

## Fluxo `/entrar`
1. Solicitar nome/identificador.
2. Solicitar curso.
3. Solicitar chave em campo privado/modal.
4. Validar chave.
5. Criar matrícula permanente.
6. Atribuir cargo correspondente.
7. Liberar categoria/canais.
8. Confirmar ao usuário.

## Regras
- Não mostrar chaves válidas em mensagens públicas.
- Não guardar tokens do bot no Git.
- Não permitir que aluno escolha livremente cargos administrativos.
- Registrar ativações administrativas.
