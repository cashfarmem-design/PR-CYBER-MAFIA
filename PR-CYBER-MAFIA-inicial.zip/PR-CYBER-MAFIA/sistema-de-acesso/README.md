# Sistema de Acesso

Este diretório será responsável pelo cadastro e validação dos alunos.

## Requisitos funcionais
- Cadastro do usuário.
- Validação de chave.
- Associação usuário ↔ curso.
- Acesso permanente.
- Prevenção de duplicidade.
- Registro de data de ativação.
- Controle de cargos/canais.
- Registro administrativo.

## Regra de acesso permanente
Uma matrícula válida possui:
`status = active`
`expires_at = NULL`

O usuário pode retornar ao curso sem precisar comprar/ativar novamente.
